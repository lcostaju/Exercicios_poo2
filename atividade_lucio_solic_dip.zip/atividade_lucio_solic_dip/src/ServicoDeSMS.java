public class ServicoDeSMS {

    void sendSMS(String mensagem, String destinatario){
        System.out.println("Enviando SMS para "+destinatario+" : "+mensagem);
    }
}
