package ispsolucao;

public interface Funcionario {
    String getCargo();
    double calculaSalario();
}

