package lsp.violacao;


public class Quadrado extends Retangulo{
    
    public Quadrado(double altura, double largura) {
        super(altura, altura);
    }
    
    public double getAltura() {
        return super.getAltura();
    }

    public void setAltura(double altura) {
        super.setAltura(altura);
    }

    public double getLargura() {
        return super.getAltura();
    }

    public void setLargura(double largura) {
        super.setLargura(largura);
    }

}

