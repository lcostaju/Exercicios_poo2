package ocp.principle.solucao;

public class OcpPrinciple {

    public static void main(String[] args) {

        // 1) Ler dados de assaliariados e estagiarios (nome, tipo, remuneração)
        // exibir a folha de pagamento com o total pago aos funcionários

    }
    
}
