package ocp.principle.solucao;

public interface Remuneravel {
    
    double remuneracao();
}

