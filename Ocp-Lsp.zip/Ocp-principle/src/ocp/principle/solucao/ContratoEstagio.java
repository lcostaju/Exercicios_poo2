package ocp.principle.solucao;

public class ContratoEstagio implements Remuneravel {
    private double bolsa;

    // construtor
    
    @Override
    public double remuneracao() {
         return bolsa;  }
    
}

