package ocp.principle.violacao;

public class Funcionario {
    // nome, tipo, remuneração; 
    // construtor
}
