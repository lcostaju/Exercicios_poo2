package ispviolacao;

public interface Funcionario {
    String getCargo();
    double calculaSalario();
    double calcula13o();
}
