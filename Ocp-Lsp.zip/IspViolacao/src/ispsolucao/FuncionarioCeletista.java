package ispsolucao;

public interface FuncionarioCeletista extends Funcionario {
    double calcula13o();
}
