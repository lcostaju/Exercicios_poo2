package ispsolucao;

public interface FuncionarioEstagiario extends Funcionario{
    void setInstituicaoEnsino(String instituicao);
}
